package retaildistrict5;

/*
 * Class: CMSC203 
 * Instructor:
 * Description: 
 * (Minnie and Mickey are getting ready to send out Holiday bonuses
 * to their hard-working employees in Retail District #5.
 * The bonuses are calculated based on how much each retail store
 * sold in each category. The retail store with the highest amount
 * sold in the category will receive $5,000. The retail store with
 * the lowest amount sold in a category will receive $1,000. All 
 * other retail stores in district #5 will receive $2,000. If a retail
 * store didn’t sale anything in a category, or they have a negative
 * sales amount, they are not eligible for a bonus in that category.
 * If only one retail store sold items in a category, 
 * they are eligible to receive only the bonus of $5000 for that category.
)
 * Due:04/08/2025
 * Platform/compiler:
 * I pledge that I have completed the programming assignment independently.
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: __________
*/

public class HolidayBonus {

    // Bonus amounts
    public static final double BONUS_HIGHEST = 5000.00;
    public static final double BONUS_LOWEST = 1000.00;
    public static final double BONUS_OTHERS = 2000.00;

    // Bonuses for each store
    public static double[] calculateHolidayBonus(double[][] sales) {
        double[] bonuses = new double[sales.length];

        for (int i = 0; i < sales.length; i++) {
            double highest = Double.MIN_VALUE;
            double lowest = Double.MAX_VALUE;
            
            for (double[] store : sales) {
                for (double sale : store) {
                    highest = Math.max(highest, sale);
                    lowest = Math.min(lowest, sale);
                }
            }

            for (int j = 0; j < sales[i].length; j++) {
                if (sales[i][j] == highest) {
                    bonuses[i] += BONUS_HIGHEST;
                } else if (sales[i][j] == lowest) {
                    bonuses[i] += BONUS_LOWEST;
                } else {
                    bonuses[i] += BONUS_OTHERS;
                }
            }
        }

        return bonuses;
    }

    public static double calculateTotalHolidayBonus(double[][] sales) {
        double total = 0;
        double[] bonuses = calculateHolidayBonus(sales);
        for (double bonus : bonuses) {
            total += bonus;
        }
        return total;
    }
}
