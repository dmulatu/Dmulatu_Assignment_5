package retaildistrict5;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class HolidayBonusTestStudent {

    @Test
    public void testCalculateHolidayBonus() {
        double[][] sales = {
            {1000, 2000, 3000},
            {4000, 5000, 6000}
        };
        double[] expectedBonuses = {5000.0, 9000.0};
        assertArrayEquals(expectedBonuses, HolidayBonus.calculateHolidayBonus(sales), 0.001);
    }

    @Test
    public void testCalculateTotalHolidayBonus() {
        double[][] sales = {
            {1000, 2000, 3000},
            {4000, 5000, 6000}
        };
        double expectedTotalBonus = 14000.0;
        assertEquals(expectedTotalBonus, HolidayBonus.calculateTotalHolidayBonus(sales), 0.001);
    }
}
