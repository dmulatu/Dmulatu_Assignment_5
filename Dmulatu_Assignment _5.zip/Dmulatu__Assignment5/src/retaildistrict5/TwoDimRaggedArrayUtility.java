package retaildistrict5;

import java.io.*;
import java.util.*;

public class TwoDimRaggedArrayUtility {

    public static double[][] readFile(File file) 
    {
        List<double[]> list = new ArrayList<>();

        try (Scanner scanner = new Scanner(file)) 
        {
            while (scanner.hasNextLine()) {
                String[] values = scanner.nextLine().trim().split(" ");
                double[] row = Arrays.stream(values).mapToDouble(Double::parseDouble).toArray();
                list.add(row);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return list.toArray(new double[0][]);
    }

    public static void writeToFile(double[][] array, File file) 
    {
        try (PrintWriter writer = new PrintWriter(file)) 
        {
            for (double[] row : array) {
                for (double value : row) {
                    writer.print(value + " ");
                }
                writer.println();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static double getTotal(double[][] array) {
        double total = 0;
        for (double[] row : array) {
            for (double value : row) {
                total += value;
            }
        }
        return total;
    }

    public static double getAverage(double[][] array) {
        double total = getTotal(array);
        int count = 0;
        for (double[] row : array) {
            count += row.length;
        }
        return total / count;
    }

    public static double getRowTotal(double[][] data, int row) {
        double total = 0;
        if (row >= 0 && row < data.length) {
            for (double value : data[row]) {
                total += value;
            }
        }
        return total;
    }

    public static double getColumnTotal(double[][] data, int col) {
        double total = 0;
        for (double[] row : data) {
            if (col < row.length) {
                total += row[col];
            }
        }
        return total;
    }

    public static double getHighestInColumn(double[][] data, int col) 
    {
        double highest = Double.NEGATIVE_INFINITY;
        for (double[] row : data) {
            if (col < row.length && row[col] > highest) {
                highest = row[col];
            }
        }
        return highest;
    }

    public static double getLowestInColumn(double[][] data, int col) 
    {
        double lowest = Double.POSITIVE_INFINITY;
        for (double[] row : data) {
            if (col < row.length && row[col] < lowest) {
                lowest = row[col];
            }
        }
        return lowest;
    }
}
