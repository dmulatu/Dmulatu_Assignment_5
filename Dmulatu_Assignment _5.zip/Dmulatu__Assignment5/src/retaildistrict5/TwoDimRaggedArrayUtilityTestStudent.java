package retaildistrict5;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TwoDimRaggedArrayUtilityTestStudent {

    double[][] sampleData = {
        {10.0, 20.0, 30.0},
        {5.0, 15.0},
        {25.0}
    };

    @Test
    public void testGetTotal() {
        assertEquals(105.0, TwoDimRaggedArrayUtility.getTotal(sampleData));
    }

    @Test
    public void testGetAverage() {
        assertEquals(105.0 / 6, TwoDimRaggedArrayUtility.getAverage(sampleData));
    }

    @Test
    public void testGetRowTotal() {
        assertEquals(60.0, TwoDimRaggedArrayUtility.getRowTotal(sampleData, 0));
        assertEquals(20.0, TwoDimRaggedArrayUtility.getRowTotal(sampleData, 1));
    }

    @Test
    public void testGetColumnTotal() {
        assertEquals(40.0, TwoDimRaggedArrayUtility.getColumnTotal(sampleData, 0)); // 10 + 5 + 25
        assertEquals(35.0, TwoDimRaggedArrayUtility.getColumnTotal(sampleData, 1)); // 20 + 15
    }

    @Test
    public void testGetHighestInColumn() {
        assertEquals(25.0, TwoDimRaggedArrayUtility.getHighestInColumn(sampleData, 0));
        assertEquals(20.0, TwoDimRaggedArrayUtility.getHighestInColumn(sampleData, 1));
    }

    @Test
    public void testGetLowestInColumn() {
        assertEquals(5.0, TwoDimRaggedArrayUtility.getLowestInColumn(sampleData, 0));
        assertEquals(15.0, TwoDimRaggedArrayUtility.getLowestInColumn(sampleData, 1));
    }
}
